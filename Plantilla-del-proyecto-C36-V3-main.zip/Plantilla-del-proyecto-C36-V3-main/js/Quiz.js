class Quiz {
  constructor(){}

  start(){
    
      question = new Question()
      question.display();
    
  }

  
}
